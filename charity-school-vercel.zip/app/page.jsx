
'use client';
import React from 'react';

export default function Page() {
  return (
    <div className="p-6 space-y-8">
      <header className="text-center">
        <img src="/school-logo.jpg" alt="School Logo" className="mx-auto w-32 h-32 rounded-full" />
        <h1 className="text-4xl font-bold mt-4">Empowering Africa’s Future Through Math & Technology</h1>
        <p className="text-lg mt-2 text-gray-600">Free education in Mathematics and Computer Technology for underprivileged children</p>
        <div className="mt-4 space-x-4">
          <button className="px-4 py-2 bg-blue-600 text-white rounded">Donate</button>
          <button className="px-4 py-2 border border-blue-600 text-blue-600 rounded">Get Involved</button>
        </div>
      </header>

      <section>
        <h2 className="text-2xl font-semibold mb-2">About Us</h2>
        <p className="text-gray-700">
          We are a charity-based educational institution in Africa committed to providing free training in Mathematics and Computer Technology to children from disadvantaged backgrounds. Our goal is to equip them with skills that can transform their future and their communities.
        </p>
      </section>

      <section>
        <h2 className="text-2xl font-semibold mb-4">Our Programs</h2>
        <div className="grid md:grid-cols-2 gap-4">
          <div className="p-4 border rounded">
            <h3 className="font-bold text-lg">Mathematics Training</h3>
            <p>Strong foundation in mathematics to enhance problem-solving and analytical thinking.</p>
          </div>
          <div className="p-4 border rounded">
            <h3 className="font-bold text-lg">Computer Technology</h3>
            <p>Hands-on computer skills including typing, software usage, and coding basics.</p>
          </div>
        </div>
      </section>

      <section>
        <h2 className="text-2xl font-semibold mb-4">Gallery</h2>
        <div className="grid md:grid-cols-3 gap-4">
          <img src="/nahim.jpg" alt="Students in front of school" className="rounded-xl shadow-md" />
          <img src="/free-computer-training-session.jpg" alt="Computer training" className="rounded-xl shadow-md" />
          <img src="/ebiz-kid.jpg" alt="Kids using laptops" className="rounded-xl shadow-md" />
        </div>
      </section>

      <section className="bg-gray-100 p-6 rounded-xl">
        <h2 className="text-2xl font-semibold mb-2">Support Our Mission</h2>
        <p className="mb-4 text-gray-700">Help us reach more children by donating. Your support provides school materials, computers, and maintenance.</p>
        <p><strong>Bank:</strong> GT Bank</p>
        <p><strong>Account Name:</strong> Ebong Everbless</p>
        <p><strong>Account Number:</strong> 0161717701</p>
        <p><strong>Crypto Wallet Name:</strong> Everbless Ebong</p>
        <p><strong>Wallet Address:</strong> LYELT9LUWX7UV5I4</p>
        <button className="mt-4 px-4 py-2 bg-green-600 text-white rounded">Donate Now</button>
      </section>

      <section>
        <h2 className="text-2xl font-semibold mb-2">Contact Us</h2>
        <p>Email: <a href="https://www.facebook.com/profile.php?id=61556995740389" className="text-blue-600">Facebook Profile</a></p>
        <p>Phone: 07080072500</p>
      </section>
    </div>
  );
}
